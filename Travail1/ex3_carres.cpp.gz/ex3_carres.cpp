#include <iostream>

using namespace std;

int main()
{
    int max = 1000;//Nous devons trouver les carr�s jsuqu'� ce que ce qeu le montant de ce carr� d�passe cette limite.
    int carre = 0;//la valeur du carr� calcul�e
    int nbr = 0;// nombre dont nous allons calculer le carr�

    cout << "carres :"<<endl;
    cout << (carre < max) << endl;

    //Tant que'on a pas d�pass� la limite pour la valeur des carr� on calcul les carr�s de nbr
    while(carre <= max){
        carre = nbr*nbr;
        if (carre <= max){
            cout << "carr� de " << nbr << " = " << carre << endl;
            nbr++;
        }
    }


    return 0;
}
