#include <iostream>

using namespace std;

//une m�thode tr�s simple qui affiche un message d'erreur � afficher dans le cas o� le nombre saisie n'est pas dans les limites pr�vues.
void usage(){
cout << "Erreur : La valeur entr�e n'est pas un nombre plus grand ou �gal � 1 et plus petit ou �gal � 10." << endl;
}


int main()
{
    int nbr = 0;//La variable qui va contenir la valeur saisie

    //On saisie la valeur � multiplier
    cout << "Veuillez entrer un nombre entre 1 et 10." << endl;
    cin >> nbr;

    //Si la valeur entr�e est bien un int qu'il est comprois entre 1 et 10
    if( !cin.fail() && nbr > 0 && nbr < 11){
        for (int i = 0; i<11; i++){
            cout << i << " * " << nbr << " = " << i * nbr << endl;
        }
    } else {
        //La valeur saisie est en dehors des limites permmises ou n'est pas un int
        usage();
    }
    return 0;
}
